package Animal;

public interface Animal {
	
	public void sound();
	
	public String toString();
	
	public boolean saveSoundToFile(String filename);
}
