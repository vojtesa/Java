package Animal;

import java.io.FileWriter;
import java.io.IOException;

public class CatImpl implements Animal{
	private static String sound = "mnau";
	private byte age;
	
	@Override
	public void sound() {
		System.out.println(sound);
	}

	@Override
	public boolean saveSoundToFile(String filename) {
		try {
			FileWriter myWriter = new FileWriter(filename);
			myWriter.write(sound);
			myWriter.close();
			return true;
		}
		catch(IOException e) {
			System.out.println(e);
		}
		return false;
	}

	public CatImpl(byte age) {
		super();
		this.age = age;
	}
	
	

}
