package cviko_08;

import cviko_08.AbstractAnimals.*;

import Animal.*;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class App {

	public static void main(String[] args) {
		Employee employee1 = new Employee("A", "A@seznam.cz", "silneHeslo".toCharArray(), employeeType.ACTIVE);
		Employee employee2 = new Employee("B", "B@seznam.cz", "silneHeslo".toCharArray(), employeeType.ACTIVE);
		Employee employee3 = new Employee("C", "C@seznam.cz", "silneHeslo".toCharArray(), employeeType.ACTIVE);
		Employee employee4 = new Employee("D", "D@seznam.cz", "silneHeslo".toCharArray(), employeeType.ACTIVE);
		Employee employee5 = new Employee("E", "E@seznam.cz", "silneHeslo".toCharArray(), employeeType.ACTIVE);
		
		List<Employee> listOfEmployees = List.of(employee1, employee2, employee3, employee4, employee5);
		
		
		Secretarian Secretarian1 = new Secretarian("Anna", "anna@seznam.cz", "silneHeslo".toCharArray(), employeeType.ACTIVE, 20);
		Secretarian Secretarian2 = new Secretarian("Bara", "bara@seznam.cz", "silneHeslo".toCharArray(), employeeType.ACTIVE, 30);
	
		Manager<Secretarian> manager1 = new Manager<Secretarian>("Adolf", 
			"Adolf@seznam.cz", 
			"silneHeslo".toCharArray(), 
			employeeType.ACTIVE, 
			listOfEmployees,
			List.of(Secretarian1));
		
		
		
		System.out.println("Manager: " + manager1.getNickname());
		System.out.println("Employees: ");
		for (Employee e : manager1.getEmployeeSortedByEmail()) {
			System.out.println(e.getNickname() + "  "+ e.getEmail());
			}
		System.out.println("Secretarian: ");
		for (Secretarian s : manager1.getListOfRelationships()) {
			System.out.println(s.getNickname() + "  " + s.getEmail());
			
		}
		
		AbstractAnimal cat = new Cat();
		AbstractAnimal dog = new Dog();
		AbstractAnimal cow = new Cow();
		cat.sound();
		dog.sound();
		cow.sound();
		
		CatImpl cat1 = new CatImpl((byte) 5);
		cat1.sound();
		cat1.saveSoundToFile("sound.txt");
	}

}
