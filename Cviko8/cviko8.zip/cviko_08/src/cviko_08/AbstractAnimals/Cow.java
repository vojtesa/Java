package cviko_08.AbstractAnimals;

public class Cow extends AbstractAnimal{

	@Override
	public void sound() {
		System.out.println("buuuuu buuuuu");
	}
	
}
