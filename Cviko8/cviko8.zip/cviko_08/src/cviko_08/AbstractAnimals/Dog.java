package cviko_08.AbstractAnimals;

public class Dog extends AbstractAnimal{
	public void sound() {
		System.out.println("haf haf");
	}

}
