package cviko_08.AbstractAnimals;

public abstract class AbstractAnimal {
	byte age;
	public abstract void sound();
		
	}

