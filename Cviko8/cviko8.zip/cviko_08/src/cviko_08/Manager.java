package cviko_08;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Manager<T> extends Employee{
	private List<Employee> listOfEmployees;
	private List<T> listOfRelationships;
	
	public Manager(String nickname, String email, char[] password, cviko_08.employeeType employeeType, 
			List<Employee> listOfEmployees, List<T> listOfRelationships) {
		super(nickname, email, password, employeeType);
		this.listOfEmployees = listOfEmployees;
		this.listOfRelationships = listOfRelationships;
	}

	public List<Employee> getListOfEmployees() {
		return listOfEmployees;
	}

	public void setListOfEmployees(List<Employee> listOfEmployees) {
		this.listOfEmployees = listOfEmployees;
	}

	public List<T> getListOfRelationships() {
		return listOfRelationships;
	}

	public void setListOfRelationships(List<T> listOfRelationships) {
		this.listOfRelationships = listOfRelationships;
	}
	
	public List<Employee> getEmployeeSortedByEmail() {
		return listOfEmployees.stream().sorted(Comparator.comparing(Employee::getEmail)).collect(Collectors.toList());
	}

}
