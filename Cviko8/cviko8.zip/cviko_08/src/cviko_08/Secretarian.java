package cviko_08;

public class Secretarian extends Employee{
	private Integer age;
	
	public Secretarian(String nickname, String email, char[] password, cviko_08.employeeType employeeType, Integer age) {
		super(nickname, email, password, employeeType);
		this.age = age;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	
	
}
