package cviko_08;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Employee {
	private String nickname, email;
	private char[] password;
	private employeeType employeeType;
	
	public Employee(String nickname, String email, char[] password, cviko_08.employeeType employeeType) {
		super();
		this.nickname = nickname;
		this.email = email;
		this.password = password;
		this.employeeType = employeeType;
	}
	
	
	
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public char[] getPassword() {
		return password;
	}
	public void setPassword(char[] password) {
		this.password = password;
	}
	public employeeType getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(employeeType employeeType) {
		this.employeeType = employeeType;
	}
}
