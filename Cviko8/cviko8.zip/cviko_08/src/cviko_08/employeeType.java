package cviko_08;

public enum employeeType {
	ACTIVE,
	INACTIVE,
	DELETED,
}
