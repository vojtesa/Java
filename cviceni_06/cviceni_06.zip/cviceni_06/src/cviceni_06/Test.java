package cviceni_06;

public class Test {

	public static void main(String[] args) {
		Zbozi pole[] = new Zbozi[4];
		pole[0] = new Potravina("Rohlik", 1.5f, 1);
		pole[1] = new Naradi("Kleste", 278f, 24);
		pole[2] = new Potravina("Chleba", 20.8f, 6);
		pole[3] = new Potravina("Jablko", 51f, 20);
		
		
		for (int i = 0; i < pole.length; i++) {
			System.out.print(pole[i].getName() + " cena: " + pole[i].getPrice());
			if (pole[i] instanceof Potravina) {
				System.out.print(" trvanlivost: " + ((Potravina)pole[i]).getTrvanlivost() + pole[i].getJednotka() + "\n");
			}
			else if (pole[i] instanceof Naradi) {
				System.out.print(" zaruka: " + ((Naradi)pole[i]).getZaruka() + pole[i].getJednotka() + "\n");
			}
		}
	}
	

}
