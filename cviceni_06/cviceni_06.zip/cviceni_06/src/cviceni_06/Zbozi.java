package cviceni_06;

public abstract class Zbozi {
	protected String nazevZbozi;
	protected Float price;
	static Float DPH = 1.21f;
	
	
	public Zbozi(String nazevZbozi, Float price) {
		this.nazevZbozi = nazevZbozi;
		this.price = price;
	}


	public String getName() {
		return nazevZbozi;
	}


	public void setName(String nazevZbozi) {
		this.nazevZbozi = nazevZbozi;
	}


	public Float getPrice() {
		return DPH * price;
	}


	public void setPrice(Float price) {
		this.price = price;
	}
	
	abstract String getJednotka();
}
