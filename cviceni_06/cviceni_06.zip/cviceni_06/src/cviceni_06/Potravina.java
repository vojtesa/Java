package cviceni_06;

public class Potravina extends Zbozi {
	
	protected Integer trvanlivost;

	public Potravina(String nazevZbozi, Float price, Integer trvanlivost) {
		super(nazevZbozi, price);
		this.trvanlivost = trvanlivost;
		}

	@Override
	String getJednotka() {
		return " dnu";
	}

	public Integer getTrvanlivost() {
		return trvanlivost;
	}

	public void setTrvanlivost(Integer trvanlivost) {
		this.trvanlivost = trvanlivost;
	}

}
