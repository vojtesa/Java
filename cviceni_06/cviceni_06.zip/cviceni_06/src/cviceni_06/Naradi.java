package cviceni_06;

public class Naradi extends Zbozi{
	
	protected Integer zaruka;

	public Naradi(String nazevZbozi, Float price, Integer zaruka) {
		super(nazevZbozi, price);
		this.zaruka = zaruka;
	}


	
	@Override
	String getJednotka() {
		return " mesicu";
	}
	
	public void setZaruka(Integer zaruka) {
		this.zaruka = zaruka;
	}
	public Integer getZaruka() {
		return zaruka;
	}	

}