public class prumerException extends java.lang.Exception{
	public prumerException()
	{
		super("Nezadan zadny prumer");
	}
	public prumerException(String text) 
	{
		super(text);	
	}

}
