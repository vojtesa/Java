import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class Databaze {
	public Databaze(int pocetPrvku)
	{
		prvkyDatabaze=new Student[pocetPrvku];
		sc=new Scanner(System.in);
	}
	
	public void setStudent()
	{
		System.out.println("Zadejte jmeno studenta, rok narozeni");
		String jmeno=sc.next();
		int rok=Test.pouzeCelaCisla(sc);
		prvkyDatabaze[posledniStudent++]=new Student(jmeno,rok);
	}
	
	public Student getStudent(int idx) 
	{
		return prvkyDatabaze[idx];
	}
	
	public void setPrumer(int idx, float prumer) throws prumerException
	{
		prvkyDatabaze[idx].setStudijniPrumer(prumer);
	}
	
	public void vypis() {
		for (int i = 0; i < prvkyDatabaze.length; i++ ) {
			System.out.println("Jmeno " + prvkyDatabaze[i].getJmeno() + " Rok narozeni: " + prvkyDatabaze[i].getRocnik());
			try{
				System.out.println("Studijni prumer: " + prvkyDatabaze[i].getStudijniPrumer());
			}
			catch(Exception e){
				System.out.println("Chyba");
			}
		}
	}
	
	public boolean ulozStudenty(String file_path) {
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fw = new FileWriter(file_path);
			bw = new BufferedWriter(fw);
			bw.write("Pocet " +prvkyDatabaze.length);
			bw.newLine();
				for (int i = 0; i < prvkyDatabaze.length; i++ ) {
					bw.write("Jmeno: " + prvkyDatabaze[i].getJmeno() + "; Rok narozeni: " + prvkyDatabaze[i].getRocnik());
					try{
						bw.write(" Studijni prumer: " + prvkyDatabaze[i].getStudijniPrumer() + "\n");
		
					}
					catch(Exception e){
						System.out.println("Chyba");
					}
				}
			return true;
			}
		catch (IOException e) {
			System.out.println("Soubor" + file_path + " nelze vytvorit");
			return false;
		}
		finally {
			try {
				bw.close();
			} catch (IOException e) {
				System.out.println("Soubor nelze zavrit");
			}
			try {
				fw.close();
			} catch (IOException e) {
				System.out.println("Soubor nelze zavrit");
			}
		}
	}
	
	public boolean nactiStudenty(String file_path) {
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file_path);
			br = new BufferedReader(fr);
			String radek = br.readLine();
			String casti[] = radek.split(" ");
			int pocetStudentu = Integer.parseInt(casti[1]);
			prvkyDatabaze = new Student[pocetStudentu];
			for (int i = 0; i < pocetStudentu; i++) {
				radek = br.readLine();
				String casti2[] = radek.split(" ");
				String jmeno = casti2[1];
				Integer rok = Integer.parseInt(casti2[4]);
				prvkyDatabaze[i] = new Student(jmeno, rok);
				try{
					Float prumer = Float.parseFloat(casti2[7]);
					prvkyDatabaze[i].setStudijniPrumer(prumer);
				}
				catch(prumerException e){
					System.out.println("nebyl nastaven prumer");
				}
				
				
				
				
			}
			return true;
		}
		catch(Exception e){
			
			return false;
		}
		finally {
			try {
				br.close();
			} catch (IOException e) {
				System.out.println("Soubor nejde zavrit");
			}
			try {
				fr.close();
			} catch (IOException e) {
				System.out.println("Soubor nejde zavrit");
			}
		}
	}
	
	private Scanner sc;
	private Student [] prvkyDatabaze;
	private int posledniStudent;
}