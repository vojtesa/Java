import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Databaze {
	public Databaze()
	{
		prvkyDatabaze= new HashMap<String, Student>();
	}
	
	public boolean setStudent(String jmeno, int rocnik)
	{
		if (prvkyDatabaze.put(jmeno, new Student(jmeno,rocnik)) == null) {
			return true;
		}
		else return false;
		
	}
	
	public Student getStudent(String jmeno) 
	{
		return prvkyDatabaze.get(jmeno);
			
	}
	
	public boolean setPrumer(String jmeno, float prumer) throws prumerException
	{
		if (prvkyDatabaze.get(jmeno) == null) return false;
		prvkyDatabaze.get(jmeno).setStudijniPrumer(prumer);			
		return true;
	}
	
	public boolean vymazStudenta(String jmeno) {
		if (prvkyDatabaze.remove(jmeno) == null) return false;
		prvkyDatabaze.remove(jmeno);
		return true;
	}
	
	
	public void vypisDatabaze() throws prumerException {
		for (String key: prvkyDatabaze.keySet()) {
			Student info = prvkyDatabaze.get(key);
			System.out.println("Jmeno: " + info.getJmeno() + " rok narozeni: " + info.getRocnik());
			try {
				System.out.print(" prumer: " + info.getStudijniPrumer());
			}
			catch(prumerException e){
				System.out.print(" prumer: " + "neni prumer" );
			}
		}
		}
	
	
	private Scanner sc;
	private Map<String, Student> prvkyDatabaze;
	private int posledniStudent;
}